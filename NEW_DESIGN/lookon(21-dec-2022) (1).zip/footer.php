<footer class=" text-dark border-top">
  <div class="container-fluid container-xl">
    <div class="row justify-content-center">
      <div class="col-md-10 col-lg-10">
        <ul class="list-unstyled d-flex justify-content-center nav">
          <li class="nav-item">
            <a href="index.php" class="nav-link gr-medium">
              Kontakt
            </a>
          </li>
          <li class="nav-item">
            <a href="index.php" class="nav-link gr-medium">
              Anmelden
            </a>
          </li>
          <li class="nav-item">
            <a href="index.php" class="nav-link gr-medium">
              Datenschutz
            </a>
          </li>
          <li class="nav-item">
            <a href="index.php" class="nav-link gr-medium">
              Impressum
            </a>
          </li>
          <li class="nav-item">
            <a href="index.php" class="nav-link gr-medium">
              Nutzungsbedingungen
            </a>
          </li>
          <li class="nav-item">
            <a href="index.php" class="nav-link gr-medium">
              AGB
            </a>
          </li>
          <li class="nav-item">
            <a href="index.php" class="nav-link gr-medium">
              Inhaltsrichtlinien
            </a>
          </li>
          <li class="nav-item">
            <a href="index.php" class="nav-link gr-medium">
              sitemap
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</footer>