<?php ?>

<head>
    <title>Lookon</title>
    <meta charset="UTF-8">
    <meta name="description" content="This is meta description Sample. We can add up to 158.">
    <meta name="keywords" content="HTML,CSS,XML,JavaScript">
    <meta name="author" content="XYZ">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <meta name=”robots” content="noindex, nofollow">
    <link rel="shortcut icon" href="favicon.png" type="image/png">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/jquery.timepicker.css" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap-datepicker.css" />
    <link rel="stylesheet" type="text/css" href="css/select2.min.css" />
    <link rel="stylesheet" type="text/css" href="css/slick.css" />
    <link rel="stylesheet" type="text/css" href="css/slick-theme.css" />
    <link rel="stylesheet" type="text/css" href="css/jquery.fancybox.min.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css">
    <link rel="stylesheet" type="text/css" href="css/steps.css">
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>